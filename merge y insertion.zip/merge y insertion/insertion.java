import java.util.Arrays;
import java.util.Random;

public class InsertionSortDemo {

    public static void insertionSort(int[] a) {
        for (int i = 1; i < a.length; i++) {
            int key = a[i];
            int j = i - 1;
            while (j >= 0 && a[j] > key) {
                a[j + 1] = a[j];
                j--;
            }
            a[j + 1] = key;
        }
    }

    public static void main(String[] args) {
        int n = 10; 
        Random rnd = new Random();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) arr[i] = rnd.nextInt(10_000_001); 

        System.out.println("Lista original: " + Arrays.toString(arr));

        int[] copy = Arrays.copyOf(arr, arr.length);
        long start = System.nanoTime();
        insertionSort(copy);
        long end = System.nanoTime();

        System.out.println("Lista ordenada: " + Arrays.toString(copy));
        double seconds = (end - start) / 1_000_000_000.0;
        System.out.printf("Tiempo Insertion Sort: %.6f s%n", seconds);
    }
}
