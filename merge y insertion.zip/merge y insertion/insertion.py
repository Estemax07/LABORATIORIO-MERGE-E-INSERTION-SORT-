import random
import time

def insertion_sort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j+1] = arr[j]
            j -= 1
        arr[j+1] = key
    return arr

n = 1000000
lista = [random.randint(0, 10000000) for _ in range(n)]
print("Lista original:", lista)

inicio = time.time()
ordenada = insertion_sort(lista.copy())
fin = time.time()

print("Lista ordenada:", ordenada)
print(f"Tiempo Insertion Sort: {fin - inicio:.6f} s")
