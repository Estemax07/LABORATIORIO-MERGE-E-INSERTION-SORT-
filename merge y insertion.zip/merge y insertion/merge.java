import java.util.Arrays;
import java.util.Random;

public class MergeSortDemo {

    public static void mergeSort(int[] a) {
        if (a.length <= 1) return;
        int[] aux = new int[a.length];
        mergeSort(a, aux, 0, a.length - 1);
    }

    private static void mergeSort(int[] a, int[] aux, int lo, int hi) {
        if (lo >= hi) return;
        int mid = lo + (hi - lo) / 2;
        mergeSort(a, aux, lo, mid);
        mergeSort(a, aux, mid + 1, hi);
        merge(a, aux, lo, mid, hi);
    }

    private static void merge(int[] a, int[] aux, int lo, int mid, int hi) {
        for (int k = lo; k <= hi; k++) aux[k] = a[k];

        int i = lo, j = mid + 1;
        for (int k = lo; k <= hi; k++) {
            if (i > mid)                a[k] = aux[j++];
            else if (j > hi)            a[k] = aux[i++];
            else if (aux[i] <= aux[j])  a[k] = aux[i++];
            else                        a[k] = aux[j++];
        }
    }

    public static void main(String[] args) {
        int n = 10; 
        Random rnd = new Random();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) arr[i] = rnd.nextInt(10_000_001); 

        System.out.println("Lista original: " + Arrays.toString(arr));

        int[] copy = Arrays.copyOf(arr, arr.length);
        long start = System.nanoTime();
        mergeSort(copy);
        long end = System.nanoTime();

        System.out.println("Lista ordenada: " + Arrays.toString(copy));
        double seconds = (end - start) / 1_000_000_000.0;
        System.out.printf("Tiempo Merge Sort: %.6f s%n", seconds);
    }
}

