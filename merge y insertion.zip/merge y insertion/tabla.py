# tabla.py


from typing import Union, Dict

tiempos: Dict[int, Dict[str, Union[float, str]]] = {
    1_000:      {"insertion": 0.018773,    "merge": 0.001863},
    10_000:     {"insertion": 1.998021,    "merge": 0.022449},
    100_000:    {"insertion": 197.410612,  "merge": 0.2868691},
    1_000_000:  {"insertion": "NE",        "merge": 3.180471},
    10_000_000: {"insertion": "NE",        "merge": 37.857516}, 
}

def nota_insertion(v: Union[float, str]) -> str:
    return "Insertion no finalizó" if isinstance(v, str) and v.strip().upper()=="NE" else ""

def fmt(v: Union[float, str]) -> str:
    return f"{v:.6f}" if isinstance(v, (int, float)) else str(v)

headers = ["n", "Insertion Sort (s)", "Merge Sort (s)", "Notas"]
orden = [1_000, 10_000, 100_000, 1_000_000, 10_000_000]

filas = []
for n in orden:
    ins = tiempos[n]["insertion"]
    mer = tiempos[n]["merge"]
    filas.append([f"{n:,}".replace(",", "."), fmt(ins), fmt(mer), nota_insertion(ins)])

tabla = [headers] + filas
anchos = [max(len(str(tabla[r][c])) for r in range(len(tabla))) for c in range(len(headers))]

def sep(char="─", cruz="┼", esq_izq="┌", esq_der="┐"):
    mid = cruz.join(char*(anchos[c]+2) for c in range(len(anchos)))
    return esq_izq + mid + esq_der
def midsep():
    return sep(char="─", cruz="┼", esq_izq="├", esq_der="┤")
def botsep():
    return sep(char="─", cruz="┼", esq_izq="└", esq_der="┘")
def linea(celda):
    return "│ " + " │ ".join(str(celda[c]).ljust(anchos[c]) for c in range(len(celda))) + " │"

print(sep()); print(linea(headers)); print(midsep())
for row in filas: print(linea(row))
print(botsep())
print("\nNota: 'NE' = no ejecutó en tiempo razonable.")
