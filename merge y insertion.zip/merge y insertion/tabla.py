# tabla_dos_maquinas.py
from typing import Union, Dict


tiempos: Dict[int, Dict[str, Union[float, str]]] = {
    1_000:      {"py_ins": 0.018773,     "py_mer": 0.001863,    "java_ins": 0.001950, "java_mer": 0.000636},
    10_000:     {"py_ins": 1.998021,     "py_mer": 0.022449,    "java_ins": 0.022707, "java_mer": 0.001606},
    100_000:    {"py_ins": 197.410612,   "py_mer": 0.2868691,   "java_ins": 1.728874, "java_mer": 0.013116},
    1_000_000:  {"py_ins": "NE",         "py_mer": 3.180471,    "java_ins": 174.496545, "java_mer": 0.101634},
    10_000_000: {"py_ins": "NE",         "py_mer": 37.857516,   "java_ins": "NE", "java_mer": 1.126792},
}

def nota_insertion(v: Union[float, str]) -> str:
    return "Insertion no finalizó" if isinstance(v, str) and v.strip().upper()=="NE" else ""

def fmt(v: Union[float, str]) -> str:
    return f"{v:.6f}" if isinstance(v, (int, float)) else str(v)

headers = ["n", "Python/M2 Insertion (s)", "Java/ASUS Insertion (s)", "Python/M2 Merge (s)", "Java/ASUS Merge (s)", "Notas"]
orden = [1_000, 10_000, 100_000, 1_000_000, 10_000_000]

filas = []
for n in orden:
    row = tiempos[n]
    filas.append([
        f"{n:,}".replace(",", "."),
        fmt(row["py_ins"]),
        fmt(row["java_ins"]),
        fmt(row["py_mer"]),
        fmt(row["java_mer"]),
        nota_insertion(row["py_ins"]) or nota_insertion(row["java_ins"])
    ])

tabla = [headers] + filas
anchos = [max(len(str(tabla[r][c])) for r in range(len(tabla))) for c in range(len(headers))]

def _sep(left, mid, right, fill="─"):
    body = mid.join(fill*(anchos[c]+2) for c in range(len(anchos)))
    return left + body + right
def topsep(): return _sep("┌","┼","┐")
def midsep(): return _sep("├","┼","┤")
def botsep(): return _sep("└","┼","┘")
def linea(celda): return "│ " + " │ ".join(str(celda[c]).ljust(anchos[c]) for c in range(len(celda))) + " │"

print(topsep()); print(linea(headers)); print(midsep())
for row in filas: print(linea(row))
print(botsep())
print("\nNota: 'NE' = no ejecutó en tiempo razonable.")

